@extends('template.layout')
@section('content')          
<div class="row">
    Welcome To Dashboard Page.
</div>
@endsection