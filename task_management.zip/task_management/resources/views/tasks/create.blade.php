@extends('template.layout')
@section('content')    
    @if(Session::get('fail'))
    <div class="alert alert-danger">
        {{ Session::get('fail') }}
    </div>
    @endif
    <div class="row">
       <div class="col-12 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Create Task</h4>
            <form action="{{ route('tasks.create') }}" method="post">
                @csrf
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="title">Title: </label>
                            <div class='col-sm-9'>
                                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="{{ old('title') }}">
                                <span class="text-danger">@error('title') {{ $message }} @enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="password">Assign to User: </label>
                            <div class='col-sm-9'>
                                <select class="form-control" name="assigned_user_id">
                                    <option value="">--Select User--</option>
                                    @foreach($users as $each_user)
                                        <option value="{{ $each_user->id }}">{{ $each_user->name }}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">@error('assigned_user_id') {{ $message }} @enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="task_status_id">Task Status: </label>
                             <div class='col-sm-9'>
                                <select class="form-control" name="task_status_id">
                                    <option value="">--Select Status--</option>
                                    @foreach($task_status as $each_status)
                                        <option value="{{ $each_status->id }}">{{ $each_status->status }}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">@error('task_status_id') {{ $message }} @enderror</span>
                             </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6"></div>
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    
                </div>
                <br>
            </form>
          </div>
        </div>
        </div>
    </div>
    @endsection  