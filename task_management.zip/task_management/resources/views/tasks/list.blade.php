@extends('template.layout')
@section('content')          
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <form class="form-inline" method="get" action="">
                   <div class="form-group">
                       <label for="task_assigned_to">Task Assigned To: </label>&nbsp;&nbsp;
                       <select name="task_assigned_to" id="task_assigned_to" class="form-control">
                           <option value="-1">--Select--</option>
                           @foreach($users as $each_user)
                               <option value="{{ $each_user->id }}" <?php echo (isset($_GET["task_assigned_to"]) && $_GET["task_assigned_to"]==$each_user->id) ? 'selected' :''?> >{{ $each_user->name }}</option>
                           @endforeach
                       </select>
                   </div>&nbsp;&nbsp;
                   <input type="submit" name="search_assigned_btn" value="Search" class="btn btn-primary">
               </form>
            </div>
        </div>
    </div>
    <div class="clearfix"></div> <br>
    
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            @if(Session::get('success_msg'))
                <div class="alert alert-success">
                    {{ Session::get('success_msg') }}
                </div>
            @endif
            @if(Session::get('error_msg'))
                <div class="alert alert-danger">
                    {{ Session::get('error_msg') }}
                </div>
            @endif
            <h4 class="card-title">Tasks</h4>
            <div style="float:right;">
                <a href="/add-task">
                  <button class="btn btn-success" >ADD</button> <br><br>  
                </a>
            </div>
            <div class="table-responsive pt-3">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th>Assigned User</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        @if(count($tasks)>0)
                            @foreach($tasks AS $record)
                                <tr>
                                  <td>{{ $record->title }}</td>
                                  <td>{{ $record->name }}</td>
                                  <td>{{ $record->status }}</td>
                                  <td> <a href="/edit-task/{{ $record->id }}"> <button class="btn btn-primary"> Edit </button> </a> | <a href="/delete-task/{{ $record->id }}"> <button class="btn btn-danger" onclick="return confirmDelete()"> Delete </button> </a> </td>
                                </tr>
                            @endforeach
                        @else
                            <tr><td colspan="4" align="center">No Records Found.</td></tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
</div>



<script type="text/javascript">
/*function confirmDelete(){
    if(confirm("Are you sure, you want to delete?")){
        console.log($(this).data("id"));
        var id = $(this).data("record_id");
        var token = $("meta[name='csrf-token']").attr("content");
        alert(id);
        alert(token);
        $.ajax({
            url: "/tasks/"+id,
            data: {
                "id": id,
                "_token": token
            },
            type: 'DELETE',
            success: function(result) {
                // Do something with the result
                console.log(result);
            }
        });
    }else{
        return false;
    }
}*/
    function confirmDelete(){
        if(confirm("Are you sure, you want to delete?")){
            return true;
        }else{
            return false;
        }
    }

</script>
@endsection
