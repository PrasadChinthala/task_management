@extends('template.layout')
@section('content')         
    @if(Session::get('fail'))
    <div class="alert alert-danger">
        {{ Session::get('fail') }}
    </div>
    @endif
    <div class="row">
        <div class="col-12 grid-margin">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Edit Task</h4>
            
            <form name="" class="form-sample" action="{{ route('tasks.update') }}" method="POST">
                @csrf
                <input type="hidden" name="id" value="{{ $task->id }}">
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="title">Title: </label>
                            <div class='col-sm-9'>
                                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="{{ $task->title }}">
                                <span class="text-danger">@error('title') {{ $message }} @enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="password">Assign to User: </label>
                            <div class='col-sm-9'>
                                <div class="form-group row">
                                    <select class="form-control" name="assigned_user_id">
                                        <option value="">--Select User--</option>
                                        @foreach($users as $each_user)
                                            <option value="{{ $each_user->id }}" {{ ($each_user->id == $task->assigned_user_id) ? 'selected' : '' }} >{{ $each_user->name }}</option>
                                        @endforeach
                                    </select>
                                    <span class="text-danger">@error('assigned_user_id') {{ $message }} @enderror</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="task_status_id">Task Status: </label>
                            <div class="form-group row">
                                <select class="form-control" name="task_status_id">
                                    <option value="">--Select Status--</option>
                                    @foreach($task_status as $each_status)
                                        <option value="{{ $each_status->id }}" {{ ($each_status->id == $task->task_status_id) ? 'selected' : '' }} >{{ $each_status->status }}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">@error('task_status_id') {{ $message }} @enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/tasks">
                            <button type="button" class="btn btn-danger">Cancel</button> <br><br>  
                        </a>
                    </div>
                </div>
                <br>
            </form>
        </div>
    </div>
        </div>
    </div>
    @endsection  