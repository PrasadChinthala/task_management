<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserAuthController extends Controller
{
   function login(){
       return view('auth.login');
   }
   function login_validate(Request $request){
      // return $request->input();
       $request->validate([
           'email'  => 'required|email',
           'password'   =>  'required|min:5|max:12'
       ]);
       $user = User::where('email','=',$request->email)->first();
       if($user){
           if(Hash::check($request->password, $user->password)){
               $session_data = array(
                    'isUserLoggedIn'    =>  true,
                    'user_id'           =>  $user->id,
                    'user_email'        =>  $user->email,
                    'user_name'         =>  $user->name,
               );
               $request->session()->put($session_data);
               return redirect('dashboard');
           }else{
               return back()->with('fail','Invalid Password.');
           }
       }else{
           return back()->with('fail','No account found for this email');
       }
   }
   function dashboard(){
       return view('user.dashboard');
       // echo "welcome to your profile";
   }
   function logout(){
       if(session()->has('isUserLoggedIn')){
           session()->pull('isUserLoggedIn');
           session()->pull('user_id');
           session()->pull('user_email');
           session()->pull('user_name');
           return redirect('login');
       }
   }
}
