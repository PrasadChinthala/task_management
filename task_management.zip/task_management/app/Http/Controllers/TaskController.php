<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // echo "welcome to Task list page.";
        /*$tasks = DB::table('tasks')
                ->join('task_status','tasks.task_status_id','=', 'task_status.id')
                ->join('users','tasks.assigned_user_id','=','users.id')
                ->select('tasks.*','task_status.status','users.name')
                ->get();*/
        // DB::connection()->enableQueryLog();
        // $queries = DB::getQueryLog();
        // dd($queries);
        // $last_query = end($queries);
        // print_r($last_query);exit;
        if(isset($request->search_assigned_btn) && $request->task_assigned_to > 0){
            // dd($request);
            $task_assigned_to = $request->task_assigned_to;
            $tasks = Task::join('task_status', 'tasks.task_status_id', '=', 'task_status.id')
                    ->join('users', 'tasks.assigned_user_id', '=', 'users.id')
                    ->where('tasks.assigned_user_id','=',$task_assigned_to)
                    ->get(['tasks.*','task_status.status','users.name']);
        }else{
            $tasks = Task::join('task_status', 'tasks.task_status_id', '=', 'task_status.id')
                    ->join('users', 'tasks.assigned_user_id', '=', 'users.id')
                    ->get(['tasks.*','task_status.status','users.name']);
        }
        $users = User::all();
        return view('tasks.list',compact('tasks','users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addTask()
    {
        // echo "welcome to Task create page.";
        $users = DB::table('users')->get();
        $task_status = DB::table('task_status')->get();
        // dd($users);
        // dd($task_status);
        return view('tasks.create',['users'=>$users, 'task_status'=>$task_status]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function createTask(Request $request)
    {
        // echo "welcome to Task store page.";
        // dd($request);
        $task = new Task;
        $task->title = $request->title;
        $task->assigned_user_id = $request->assigned_user_id;
        $task->task_status_id = $request->task_status_id;
        $task->save();
        if($task->id>0){
            $request->session()->flash('success_msg', 'Task has been created and assigned successfully.');
        }else{
            $request->session()->flash('error_msg', 'Something went wrong, Task has not been created. Please try again after sometime');
        }
        return redirect('tasks');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        echo "welcome to Task individual page.";
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editTask($id)
    {
        // echo $task;exit;
        $task = Task::find($id);
        $users = DB::table('users')->get();
        $task_status = DB::table('task_status')->get();
        // dd($users);
        return view('tasks.edit',compact('task','users', 'task_status'));   
        // return view('tasks.edit');

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateTask(Request $request)
    {
       // echo "it's working";
       // echo $id;
       // echo "<pre>",print_r($request->all());exit;
       $id = $request->id;
       $task = Task::find($id);
       $task->title = $request->title;
       $task->assigned_user_id = $request->assigned_user_id;
       $task->task_status_id = $request->task_status_id;
       try {
            $task->save();
            $request->session()->flash('success_msg', 'Task has been updated successfully.');
       }
       catch(\Illuminate\Database\QueryException $e){
            $request->session()->flash('error_msg', 'Something went wrong, Task has not been updated. Please try again after sometime');
       }
       return redirect('tasks');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteTask($id)
    {
        // echo $id;exit;
        $task = Task::find($id);
        $is_deleted = $task->delete();
        return back()->with('success_msg', 'Task has been deleted successfully!');
    }
}
