<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AuthCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if(!session()->has('isUserLoggedIn') && ($request->url() != url('login') && $request->url() != url('register'))){
            return redirect('/login')->with('fail', 'You must be logged in.');
        }
        
        return $next($request);
    }
}
