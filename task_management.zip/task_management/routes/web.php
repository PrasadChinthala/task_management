<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserAuthController;
use App\Http\Controllers\TaskController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/login_validate', [UserAuthController::class, 'login_validate'])->name('auth.login_validate');
Route::get('logout', [UserAuthController::class, 'logout']);
Route::middleware(['AlreadyLoggedIn'])->group(function () {
    Route::get('/login', [UserAuthController::class, 'login']);
});
Route::middleware(['AuthCheck'])->group(function () {
    Route::get('dashboard', [UserAuthController::class, 'dashboard']);
    Route::get('/tasks', [TaskController::class, 'index']);
    Route::get('/add-task', [TaskController::class, 'addTask']);
    Route::post('/create-task', [TaskController::class, 'createTask'])->name('tasks.create');
    Route::get('/edit-task/{id}', [TaskController::class, 'editTask']);
    Route::post('/update-task', [TaskController::class, 'updateTask'])->name('tasks.update');
    Route::get('/delete-task/{id}', [TaskController::class, 'deleteTask']);
});