<?php $__env->startSection('content'); ?>         
    <?php if(Session::get('fail')): ?>
    <div class="alert alert-danger">
        <?php echo e(Session::get('fail')); ?>

    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-12 grid-margin">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Edit Task</h4>
            
            <form name="" class="form-sample" action="<?php echo e(route('tasks.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($task->id); ?>">
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="title">Title: </label>
                            <div class='col-sm-9'>
                                <input type="text" name="title" class="form-control" placeholder="Enter Title" value="<?php echo e($task->title); ?>">
                                <span class="text-danger"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="password">Assign to User: </label>
                            <div class='col-sm-9'>
                                <div class="form-group row">
                                    <select class="form-control" name="assigned_user_id">
                                        <option value="">--Select User--</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($each_user->id); ?>" <?php echo e(($each_user->id == $task->assigned_user_id) ? 'selected' : ''); ?> ><?php echo e($each_user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"><?php $__errorArgs = ['assigned_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="task_status_id">Task Status: </label>
                            <div class="form-group row">
                                <select class="form-control" name="task_status_id">
                                    <option value="">--Select Status--</option>
                                    <?php $__currentLoopData = $task_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($each_status->id); ?>" <?php echo e(($each_status->id == $task->task_status_id) ? 'selected' : ''); ?> ><?php echo e($each_status->status); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger"><?php $__errorArgs = ['task_status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='row'>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="/tasks">
                            <button type="button" class="btn btn-danger">Cancel</button> <br><br>  
                        </a>
                    </div>
                </div>
                <br>
            </form>
        </div>
    </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>  
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task_management\resources\views/tasks/edit.blade.php ENDPATH**/ ?>