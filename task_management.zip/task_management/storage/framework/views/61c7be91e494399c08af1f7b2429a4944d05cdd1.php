
<?php $__env->startSection('content'); ?>          
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <form class="form-inline" method="get" action="">
                   <div class="form-group">
                       <label for="task_assigned_to">Task Assigned To: </label>&nbsp;&nbsp;
                       <select name="task_assigned_to" id="task_assigned_to" class="form-control">
                           <option value="-1">--Select--</option>
                           <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($each_user->id); ?>" <?php echo (isset($_GET["task_assigned_to"]) && $_GET["task_assigned_to"]==$each_user->id) ? 'selected' :''?> ><?php echo e($each_user->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                   </div>&nbsp;&nbsp;
                   <input type="submit" name="search_assigned_btn" value="Search" class="btn btn-primary">
               </form>
            </div>
        </div>
    </div>
    <div class="clearfix"></div> <br>
    
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <?php if(Session::get('success_msg')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success_msg')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('error_msg')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('error_msg')); ?>

                </div>
            <?php endif; ?>
            <h4 class="card-title">Tasks</h4>
            <div style="float:right;">
                <a href="/add-task">
                  <button class="btn btn-success" >ADD</button> <br><br>  
                </a>
            </div>
            <div class="table-responsive pt-3">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th>Assigned User</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php if(count($tasks)>0): ?>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($record->title); ?></td>
                                  <td><?php echo e($record->name); ?></td>
                                  <td><?php echo e($record->status); ?></td>
                                  <td> <a href="/edit-task/<?php echo e($record->id); ?>"> <button class="btn btn-primary"> Edit </button> </a> | <a href="/delete-task/<?php echo e($record->id); ?>"> <button class="btn btn-danger" onclick="return confirmDelete()"> Delete </button> </a> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr><td colspan="4" align="center">No Records Found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
</div>



<script type="text/javascript">
/*function confirmDelete(){
    if(confirm("Are you sure, you want to delete?")){
        console.log($(this).data("id"));
        var id = $(this).data("record_id");
        var token = $("meta[name='csrf-token']").attr("content");
        alert(id);
        alert(token);
        $.ajax({
            url: "/tasks/"+id,
            data: {
                "id": id,
                "_token": token
            },
            type: 'DELETE',
            success: function(result) {
                // Do something with the result
                console.log(result);
            }
        });
    }else{
        return false;
    }
}*/
    function confirmDelete(){
        if(confirm("Are you sure, you want to delete?")){
            return true;
        }else{
            return false;
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task_management\resources\views/tasks/list.blade.php ENDPATH**/ ?>