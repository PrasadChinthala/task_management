<?php $__env->startSection('content'); ?>          
<div class="row">
    This is your profile page.
</div>
<?php $__env->stopSection(); ?>
          
        


<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task_management\resources\views/user/profile.blade.php ENDPATH**/ ?>