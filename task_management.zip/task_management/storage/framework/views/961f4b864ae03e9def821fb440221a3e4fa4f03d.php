<?php $__env->startSection('content'); ?>          
<div class="row">
    Welcome To Dashboard Page.
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\task_management\resources\views/user/dashboard.blade.php ENDPATH**/ ?>